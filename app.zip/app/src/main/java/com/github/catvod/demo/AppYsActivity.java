package com.github.catvod.demo;

import android.app.Activity;
import android.os.Bundle;

import com.github.catvod.spider.AppYsV2;
import com.github.catvod.spider.Dyls;
import com.github.catvod.spider.XPath;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AppYsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        new Thread(new Runnable() {
            @Override
            public void run() {
                Dyls dyls = new Dyls();
                dyls.init(AppYsActivity.this);
                String json = dyls.homeContent(true);
                System.out.println(json);
                JSONObject homeContent = null;
                try {
                    homeContent = new JSONObject(dyls.homeVideoContent());
                    System.out.println(homeContent.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                System.out.println(dyls.categoryContent("1", "1", false, null));
                if (homeContent != null) {
                    try {
                        List<String> ids = new ArrayList<String>();
                        JSONArray array = homeContent.getJSONArray("list");
                        for (int i = 0; i < array.length() && i < 3; i++) {
                            try {
                                ids.clear();
                                ids.add(array.getJSONObject(i).getString("vod_id"));
                                System.out.println(dyls.detailContent(ids));
                                JSONObject detailContent = new JSONObject(dyls.detailContent(ids)).getJSONArray("list").getJSONObject(0);
                                String[] playFlags = detailContent.getString("vod_play_from").split("\\$\\$\\$");
                                String[] playUrls = detailContent.getString("vod_play_url").split("\\$\\$\\$");
                                for (int j = 0; j < playFlags.length; j++) {
                                    String pu = playUrls[j].split("#")[0].split("\\$")[1];
                                    System.out.println(dyls.playerContent(playFlags[j], pu, new ArrayList<>()));
                                }
                            } catch (Throwable th) {

                            }
                        }
                    } catch (Throwable th) {

                    }
                }
                System.out.println(dyls.searchContent("陪你一起", false));
                System.out.println(dyls.searchContent("顶楼", false));
            }
        }).start();
    }
}